from django.forms import ModelForm, Select, TextInput, NumberInput, DateInput
from django import forms
from .models import Empleado, Rol, Cargo, Departamento, TipoContrato, Permiso, TipoPermiso



class Register(forms.Form):
    username = forms.CharField(label="Usuario", max_length=100, widget=forms.TextInput(attrs={'class': 'form-control'}))
    password1 = forms.CharField(label="Contraseña", max_length=100, widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    password2 = forms.CharField(label="Confirme su contraseña", max_length=100, widget=forms.PasswordInput(attrs={'class': 'form-control'}))

class Login(forms.Form):
    username = forms.CharField(label="Usuario", max_length=100, widget=forms.TextInput(attrs={'class': 'form-control'}))
    password = forms.CharField(label="Contraseña", max_length=100, widget=forms.PasswordInput(attrs={'class': 'form-control'}))

SEXO_CHOICES = [
    ('', 'Seleccione un género'),
    ('M', 'Masculino'), 
    ('F', 'Femenino'), 
]

sexo = forms.ChoiceField(
    choices=SEXO_CHOICES,
    widget=forms.Select(attrs={'class': 'form-control'})
)

class EmpleadoForm(ModelForm):
    class Meta:
        model = Empleado
        fields = '__all__'

        widgets = {
            'nombre': TextInput(attrs={'class': 'form-control'}),
            'cedula': TextInput(attrs={
                'class': 'form-control',
                'pattern': '[0-9]{10}',
                'maxlength': '10',
                'inputmode': 'numeric',
            }),
            'direccion': TextInput(attrs={'class': 'form-control'}),
            'sexo': Select(attrs={'class': 'form-select'}),
            'sueldo': NumberInput(attrs={'class': 'form-control'}),
            'cargo': Select(attrs={'class': 'form-select'}),
            'departamento': Select(attrs={'class': 'form-select'}),
            'tipo_contrato': Select(attrs={'class': 'form-select'}),
        }

class RolForm(ModelForm):
    class Meta:
        model = Rol
        fields = '__all__'

        widgets = {
            'empleado': Select(attrs={'class': 'form-select'}),
            'aniomes': DateInput(attrs={
                'type': 'date',
                'class': 'form-control'
            }),
            'sueldo': NumberInput(attrs={'class': 'form-control'}),
            'horas_extra': NumberInput(attrs={'class': 'form-control'}),
            'bono': NumberInput(attrs={'class': 'form-control'}),
            'iess': NumberInput(attrs={'class': 'form-control'}),
            'tot_ing': NumberInput(attrs={'class': 'form-control'}),
            'tot_des': NumberInput(attrs={'class': 'form-control'}),
            'neto': NumberInput(attrs={'class': 'form-control'}),
        }

class CargoForm(forms.ModelForm):
    class Meta:
        model = Cargo
        fields = '__all__'  # Asegúrate de incluir 'activo' aquí

        widgets = {
            'descripcion': forms.TextInput(attrs={'class': 'form-control'}),
            'nivel': forms.Select(attrs={'class': 'form-select'}),  # Si usas 'choices', usa Select
            'salario_base': forms.NumberInput(attrs={'class': 'form-control'}),
            'activo': forms.CheckboxInput(attrs={'class': 'form-check-input'}),  # Para manejar el checkbox
        }
        
class DepartamentoForm(forms.ModelForm):
    class Meta:
        model = Departamento
        fields = '__all__'
        widgets = {
            'descripcion': forms.TextInput(attrs={'class': 'form-control'}),
            'salario_base': forms.NumberInput(attrs={'class': 'form-control'}),
            'activo': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }

class TipoContratoForm(forms.ModelForm):
    class Meta:
        model = TipoContrato
        fields = '__all__'
        widgets = {
            'descripcion': forms.TextInput(attrs={'class': 'form-control'}),
        }



class PermisoForm(forms.ModelForm):
    class Meta:
        model = Permiso
        fields = ['empleado', 'fecha_permiso', 'tipo_permiso', 'dias', 'horas', 'is_active']
        widgets = {
            'fecha_permiso': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'empleado': forms.Select(attrs={'class': 'form-control'}),
            'tipo_permiso': forms.Select(attrs={'class': 'form-control'}),
            'dias': forms.NumberInput(attrs={'class': 'form-control', 'min': 0}),
            'horas': forms.NumberInput(attrs={'class': 'form-control', 'min': 0}),
            'is_active': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }
        labels = {
            'empleado': 'Empleado',
            'fecha_permiso': 'Fecha del Permiso',
            'tipo_permiso': 'Tipo de Permiso',
            'dias': 'Cantidad de Días',
            'horas': 'Cantidad de Horas',
            'is_active': '¿Está activo?',
        }

    def clean(self):
        cleaned_data = super().clean()
        dias = cleaned_data.get("dias")
        horas = cleaned_data.get("horas")

        if (not dias or dias < 1) and (not horas or horas < 1):
            raise forms.ValidationError("Debe ingresar al menos 1 día o 1 hora de permiso.")

        return cleaned_data


