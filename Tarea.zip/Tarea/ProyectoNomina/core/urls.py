from django.urls import path
from .views import (
    cargos_list, cargos_create, cargos_update, cargos_delete,
    departamentos_list, departamentos_create, departamentos_update, departamentos_delete,
    tipos_contratos_list, tipos_contratos_create, tipos_contratos_update, tipos_contratos_delete,
    roles_list, roles_create, roles_update, roles_delete,
    register, alert, error, cerrar_secion, iniciar_secion,
    empleados_create, empleados_delete, empleados_list, empleados_update, permisos_list, permisos_delete,permisos_create,permisos_update
)

app_name = 'core'

urlpatterns = [
    # Empleados
    path('empleados_list/', empleados_list, name='empleados_list'),
    path('empleados_create/', empleados_create, name='empleados_create'),
    path('empleados_update/<int:id>/', empleados_update, name='empleados_update'),
    path('empleados_delete/<int:id>/', empleados_delete, name='empleados_delete'),

    # Roles
    path('roles_list/', roles_list, name='roles_list'),
    path('roles_create/', roles_create, name='roles_create'),
    path('roles_update/<int:id>/', roles_update, name='roles_update'),
    path('roles_delete/<int:id>/', roles_delete, name='roles_delete'),

    # Usuarios
    path("register/", register, name="register"),
    path("alert/", alert, name="alert"),
    path("error/", error, name="error"),
    path("cerrar_secion/", cerrar_secion, name="cerrar_secion"),
    path("iniciar_secion/", iniciar_secion, name="iniciar_secion"),

    # Cargos
    path('cargos/', cargos_list, name='cargos_list'),
    path('cargos/crear/', cargos_create, name='cargos_create'),
    path('cargos/editar/<int:id>/', cargos_update, name='cargos_update'),
    path('cargos/eliminar/<int:id>/', cargos_delete, name='cargos_delete'),

    # Departamentos
    path('departamentos/', departamentos_list, name='departamentos_list'),
    path('departamentos/create/', departamentos_create, name='departamentos_create'),
    path('departamentos/update/<int:id>/', departamentos_update, name='departamentos_update'),
    path('departamentos/delete/<int:id>/', departamentos_delete, name='departamentos_delete'),

    # Tipos de Contrato
    path('tipos_contratos/', tipos_contratos_list, name='tipos_contratos_list'),
    path('tipos_contratos/create/', tipos_contratos_create, name='tipos_contratos_create'),
    path('tipos_contratos/update/<int:id>/', tipos_contratos_update, name='tipos_contratos_update'),
    path('tipos_contratos/delete/<int:id>/', tipos_contratos_delete, name='tipos_contratos_delete'),
    
    #Tipo de permiso 
    path('permisos/',permisos_list, name='permisos_list'),
    path('permisos/crear/',permisos_create, name='permisos_create'),
    path('permisos/actualizar/<int:id>/',permisos_update, name='permisos_update'),
    path('permisos/eliminar/<int:id>/',permisos_delete, name='permisos_delete'),
]

