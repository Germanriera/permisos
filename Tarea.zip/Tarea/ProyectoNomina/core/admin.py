from django.contrib import admin
from .models import Cargo, Departamento, TipoContrato, Empleado, Rol, TipoPermiso
# Register your models here.
admin.site.site_header = "Sistema de Nómina"
admin.site.register(Cargo)
admin.site.register(Departamento)
admin.site.register(TipoContrato)
admin.site.register(Empleado)
admin.site.register(Rol)
admin.site.register(TipoPermiso)