
from django.shortcuts import render ,redirect,HttpResponse
#from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import login,logout, authenticate
from django.db import IntegrityError
from django.contrib.auth.decorators import login_required
from .models import Empleado, Rol
from core.forms import EmpleadoForm,Register,Login, RolForm
from .models import Cargo, Departamento, TipoContrato,Permiso
from .forms import CargoForm, DepartamentoForm, TipoContratoForm,PermisoForm

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
# Create your views here.
def home(request):
    data = {

    }
    return render(request, 'home.html', data)

@login_required
def empleados_list(request):
    empleados = Empleado.objects.all()
    query = request.GET.get('q', None)
    if query: empleados = empleados.filter(nombre__icontains=query)
    else: Empleado.objects.all()
    context = {'empleados': empleados, 'title':'Lista de Empleados'}
    return render(request, 'empleados/list.html', context)
@login_required
def empleados_create(request):
    context={'title':'Ingresar Empleado'}
    print("metodo: ",request.method)
    if request.method == "GET":
        form = EmpleadoForm()# instancia el formulario con los campos vacios
        context['form'] = form
        return render(request, 'empleados/create.html', context)
    else:
        form = EmpleadoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('core:empleados_list')
        else:
            context['form'] = form
            return render(request, 'empleados/create.html',context) 
@login_required
def empleados_update(request, id):
   context={'title':'Actualizar Empleado'}
   empleado = Empleado.objects.get(pk=id)
   if request.method == "GET":
      form = EmpleadoForm(instance=empleado)# instancia el formulario con los datos del doctor
      context['form'] = form
      return render(request, 'empleados/update.html', context)
   else:
      form = EmpleadoForm(request.POST,instance=empleado)
      if form.is_valid():
          form.save()
          return redirect('core:empleados_list')
      else:
          context['form'] = form
          return render(request, 'empleados/update.html', context)
@login_required
def empleados_delete(request,id):
    context={'title':'Eliminar Empleado'}
    empleado=None
    try:
        empleado = Empleado.objects.get(pk=id)
        if request.method == "GET":
            context = {'title':'Eliminar Empleado','empleado':empleado,'error':''}
            return render(request, 'empleados/delete.html',context)  
        else: 
            empleado.delete()
            return redirect('core:empleados_list')
    except:
        context = {'title':'Datos del Empleado','empleados':empleado,'error':'Error al eliminar el empleado'}
        return render(request, 'doctor/delete.html',context)

@login_required
def roles_list(request):
    roles = Rol.objects.all()
    query = request.GET.get('q', None)
    if query:
        roles = roles.filter(empleado__nombre__icontains=query)
    context = {'roles': roles, 'title': 'Lista de Roles'}
    return render(request, 'rol/list.html', context)
 
@login_required
def roles_create(request):
    context = {'title': 'Crear Rol'}
    if request.method == "GET":
        form = RolForm()
        context['form'] = form
        return render(request, 'rol/create.html', context)
    else:
        form = RolForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Rol creado exitosamente.')
            return redirect('core:roles_list')
        else:
            context['form'] = form
            return render(request, 'rol/create.html', context)

@login_required
def roles_update(request, id):
    context = {'title': 'Actualizar Rol'}
    rol = Rol.objects.get(pk=id)
    if request.method == "GET":
        form = RolForm(instance=rol)
        context['form'] = form
        return render(request, 'rol/update.html', context)
    else:
        form = RolForm(request.POST, instance=rol)
        if form.is_valid():
            form.save()
            messages.success(request, 'Rol actualizado exitosamente.')
            return redirect('core:roles_list')
        else:
            context['form'] = form
            return render(request, 'rol/update.html', context)

@login_required
def roles_delete(request, id):
    context = {'title': 'Eliminar Rol'}
    try:
        rol = Rol.objects.get(pk=id)
        if request.method == "GET":
            context['rol'] = rol
            return render(request, 'rol/delete.html', context)
        else:
            rol.delete()
            messages.success(request, 'Rol eliminado exitosamente.')
            return redirect('core:roles_list')
    except Rol.DoesNotExist:
        messages.error(request, 'Rol no encontrado.')
        return redirect('core:rol_list')

# Alertas y errores
def alert(request):
    return render(request,"login/alert.html")
def error(request):
    return render(request,"login/error.html")
def register(request):
    form=Register()
    datos={"form":form}
    if request.method == "GET":
        return render(request,"login/register.html",datos)
    else:
        if request.POST["password1"] == request.POST["password2"] :
           try:
                user=User.objects.create_user(username=request.POST["username"],password=request.POST["password1"])
                user.save()
                login(request,user)
                messages.success(request,'¡Registro exitoso! Serás redirigido al inicio.')
                return redirect("core:alert")
           except IntegrityError:
               messages.success(request,'¡Usuario ya existente!')
               return redirect("core:error")
        messages.success(request,'¡Contraseña no coincide!')
        return redirect("core:error")
@login_required
def cerrar_secion(request):
    logout(request)
    return redirect("home")

def iniciar_secion(request):
    if request.method=="GET":
        return render(request,"login/iniciar_secion.html",{"form":Login})
    
    else:
        user=authenticate(request,username=request.POST["username"],password=request.POST["password"])
        if user is None:
            messages.success(request,"¡Usuario no encontrado!")
            return render(request,"login/iniciar_secion.html",{"form":Login})
        else: 
            login(request,user) 
            return redirect("home")
        
@login_required
def cargos_list(request):
    cargos = Cargo.objects.all()
    return render(request, 'cargos/list.html', {
        'cargos': cargos,
        'title': 'Lista de Cargos'
    })

@login_required
def cargos_create(request):
    if request.method == 'POST':
        form = CargoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('core:cargos_list')
    else:
        form = CargoForm()
    return render(request, 'cargos/create.html', {
        'form': form,
        'title': 'Registrar Nuevo Cargo'
    })

@login_required
def cargos_update(request, id):
    cargo = get_object_or_404(Cargo, pk=id)
    if request.method == 'POST':
        form = CargoForm(request.POST, instance=cargo)
        if form.is_valid():
            form.save()
            return redirect('core:cargos_list')
    else:
        form = CargoForm(instance=cargo)
    return render(request, 'cargos/update.html', {
        'form': form,
        'title': 'Actualizar Cargo'
    })

@login_required
def cargos_delete(request, id):
    cargo = get_object_or_404(Cargo, pk=id)
    if request.method == 'POST':
        cargo.delete()
        return redirect('core:cargos_list')
    return render(request, 'cargos/delete.html', {
        'cargo': cargo,
        'title': 'Eliminar Cargo'
    })

# CRUD para Departamento
@login_required
def departamentos_list(request):
    departamentos = Departamento.objects.all()
    return render(request, 'departamentos/list.html', {'departamentos': departamentos, 'title': 'Lista de Departamentos'})

@login_required
def departamentos_create(request):
    if request.method == 'POST':
        form = DepartamentoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('core:departamentos_list')
    else:
        form = DepartamentoForm()
    return render(request, 'departamentos/create.html', {'form': form, 'title': 'Crear Departamento'})

@login_required
def departamentos_update(request, id):
    departamento = get_object_or_404(Departamento, pk=id)
    if request.method == 'POST':
        form = DepartamentoForm(request.POST, instance=departamento)
        if form.is_valid():
            form.save()
            return redirect('core:departamentos_list')
    else:
        form = DepartamentoForm(instance=departamento)
    return render(request, 'departamentos/update.html', {'form': form, 'title': 'Actualizar Departamento'})

@login_required
def departamentos_delete(request, id):
    departamento = get_object_or_404(Departamento, pk=id)
    if request.method == 'POST':
        departamento.delete()
        return redirect('core:departamentos_list')
    return render(request, 'departamentos/delete.html', {'departamento': departamento, 'title': 'Eliminar Departamento'})

# CRUD para TipoContrato

@login_required
def tipos_contratos_list(request):
    tipos_contratos = TipoContrato.objects.all()
    return render(request, 'tipos_contratos/list.html', {
        'tipos_contratos': tipos_contratos,
        'title': 'Lista de Tipos de Contrato'
    })

@login_required
def tipos_contratos_create(request):
    if request.method == 'POST':
        form = TipoContratoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('core:tipos_contratos_list')  # ✅ corregido
    else:
        form = TipoContratoForm()
    return render(request, 'tipos_contratos/create.html', {
        'form': form,
        'title': 'Crear Tipo de Contrato'
    })

@login_required
def tipos_contratos_update(request, id):
    tipo_contrato = get_object_or_404(TipoContrato, pk=id)
    if request.method == 'POST':
        form = TipoContratoForm(request.POST, instance=tipo_contrato)
        if form.is_valid():
            form.save()
            return redirect('core:tipos_contratos_list')  # ✅ corregido
    else:
        form = TipoContratoForm(instance=tipo_contrato)
    return render(request, 'tipos_contratos/update.html', {
        'form': form,
        'title': 'Actualizar Tipo de Contrato'
    })

@login_required
def tipos_contratos_delete(request, id):
    tipo_contrato = get_object_or_404(TipoContrato, pk=id)
    if request.method == 'POST':
        tipo_contrato.delete()
        return redirect('core:tipos_contratos_list')  # ✅ corregido
    return render(request, 'tipos_contratos/delete.html', {
        'tipo_contrato': tipo_contrato,
        'title': 'Eliminar Tipo de Contrato'
    })

@login_required
def permisos_list(request):
    permisos = Permiso.objects.all()
    query = request.GET.get('q', None)
    if query:
        permisos = permisos.filter(empleado__nombre__icontains=query)
    context = {'permisos': permisos, 'title': 'Lista de Permisos'}
    return render(request, 'permisos/list.html', context)

@login_required
def permisos_create(request):
    context = {'title': 'Crear Permiso'}
    if request.method == 'GET':
        form = PermisoForm()
        context['form'] = form
        return render(request, 'permisos/create.html', context)
    else:
        form = PermisoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Permiso creado correctamente.")
            return redirect('core:permisos_list')
        else:
            context['form'] = form
            return render(request, 'permisos/create.html', context)

@login_required
def permisos_update(request, id):
    permiso = get_object_or_404(Permiso, pk=id)
    context = {'title': 'Actualizar Permiso'}
    if request.method == 'GET':
        form = PermisoForm(instance=permiso)
        context['form'] = form
        return render(request, 'permisos/update.html', context)
    else:
        form = PermisoForm(request.POST, instance=permiso)
        if form.is_valid():
            form.save()
            messages.success(request, "Permiso actualizado correctamente.")
            return redirect('core:permisos_list')
        else:
            context['form'] = form
            return render(request, 'permisos/update.html', context)

@login_required
def permisos_delete(request, id):
    permiso = get_object_or_404(Permiso, pk=id)
    context = {'title': 'Eliminar Permiso', 'permiso': permiso}
    if request.method == 'POST':
        permiso.delete()
        messages.success(request, "Permiso eliminado correctamente.")
        return redirect('core:permisos_list')
    return render(request, 'permisos/delete.html', context)
